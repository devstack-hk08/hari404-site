import { ArrowUpRight, LockKeyhole, Sparkles, Globe2, Layers3, Code2 } from 'lucide-react'
import type { Project } from '../types'

const icons = [Sparkles, Layers3, LockKeyhole, Globe2, Code2]

export default function ProjectCard({ project, index }: { project: Project; index: number }) {
  const Icon = icons[index % icons.length]
  return (
    <article className={`project-card project-${project.visual}`}>
      <div className="project-art">
        <div className="art-topline"><span>HARI404 / SELECTED WORK</span><span>{project.number} — 05</span></div>
        <div className="art-grid" />
        <div className="art-orbit orbit-one" />
        <div className="art-orbit orbit-two" />
        <div className="art-symbol"><Icon strokeWidth={1.1} /></div>
        <div className="art-word">{project.visual === 'vault' ? 'SECURE' : project.name.split(' ')[0].toUpperCase()}</div>
        <div className="art-bottomline"><span>INDEPENDENT PROJECT</span><span>{project.year}</span></div>
      </div>
      <div className="project-meta">
        <div>
          <div className="eyebrow">{project.number} / {project.type}</div>
          <h3>{project.name}</h3>
          <p>{project.description}</p>
          <div className="tag-row">{project.stack.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
        </div>
        {project.url ? (
          <a className="round-link" href={project.url} target="_blank" rel="noreferrer" aria-label={`Open ${project.name}`}><ArrowUpRight /></a>
        ) : <span className="round-link unavailable" title="Project link not supplied"><LockKeyhole /></span>}
      </div>
    </article>
  )
}
