import { useRef, type ReactNode } from 'react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

gsap.registerPlugin(ScrollTrigger)

type Props = {
  children: ReactNode
  className?: string
  delay?: number
  y?: number
  once?: boolean
}

export default function Reveal({ children, className = '', delay = 0, y = 42, once = true }: Props) {
  const ref = useRef<HTMLDivElement>(null)

  useGSAP(() => {
    if (!ref.current) return
    gsap.fromTo(ref.current,
      { autoAlpha: 0, y, filter: 'blur(8px)' },
      {
        autoAlpha: 1, y: 0, filter: 'blur(0px)', duration: 1.05,
        delay, ease: 'power3.out',
        scrollTrigger: {
          trigger: ref.current,
          start: 'top 88%',
          toggleActions: once ? 'play none none none' : 'play reverse play reverse',
        },
      },
    )
  }, { scope: ref, dependencies: [delay, y, once] })

  return <div ref={ref} className={className}>{children}</div>
}
