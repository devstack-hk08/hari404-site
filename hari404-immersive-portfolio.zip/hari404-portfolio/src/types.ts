export type Project = {
  number: string
  name: string
  type: string
  description: string
  stack: string[]
  url: string
  visual: string
  year: string
}
