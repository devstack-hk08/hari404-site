import { useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import Lenis from 'lenis'
import {
  ArrowDown, ArrowDownRight, ArrowRight, ArrowUpRight, Github, Linkedin,
  Mail, Menu, Moon, Sun, X, Sparkles, Code2, Network, ShieldCheck, Database,
  MousePointer2, MoveUpRight,
} from 'lucide-react'
import Reveal from './components/Reveal'
import ProjectCard from './components/ProjectCard'
import { projects, skills, principles } from './data'
import './styles.css'
import avatarImage from './assets/hari-avatar.jpg'

gsap.registerPlugin(ScrollTrigger, useGSAP)

const navItems = [
  ['About', '#about'], ['Expertise', '#expertise'], ['Work', '#work'],
  ['Journey', '#journey'], ['Contact', '#contact'],
]

function App() {
  const [theme, setTheme] = useState<'dark' | 'light'>(() => (localStorage.getItem('hari-theme') as 'dark' | 'light') || 'dark')
  const [menuOpen, setMenuOpen] = useState(false)
  const [scroll, setScroll] = useState(0)
  const root = useRef<HTMLDivElement>(null)
  const heroTitle = useRef<HTMLHeadingElement>(null)

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    localStorage.setItem('hari-theme', theme)
  }, [theme])

  useEffect(() => {
    const lenis = new Lenis({ duration: 1.15, smoothWheel: true, wheelMultiplier: 0.9, touchMultiplier: 1.5 })
    let raf = 0
    const tick = (time: number) => { lenis.raf(time); raf = requestAnimationFrame(tick) }
    raf = requestAnimationFrame(tick)
    lenis.on('scroll', ScrollTrigger.update)
    const update = () => setScroll(window.scrollY / Math.max(1, document.documentElement.scrollHeight - window.innerHeight))
    window.addEventListener('scroll', update, { passive: true })
    return () => { cancelAnimationFrame(raf); window.removeEventListener('scroll', update); lenis.destroy() }
  }, [])

  useGSAP(() => {
    const intro = gsap.timeline({ defaults: { ease: 'power4.out' } })
    intro.from('.hero-kicker', { y: 20, autoAlpha: 0, duration: .7 })
      .from('.hero-line span', { yPercent: 120, rotate: 3, duration: 1.1, stagger: .09 }, '-=.35')
      .from('.hero-copy, .hero-portrait, .hero-bottom', { y: 35, autoAlpha: 0, duration: .9, stagger: .12 }, '-=.55')

    gsap.to('.hero-portrait-wrap', {
      yPercent: 18, rotate: -3, scale: .88, ease: 'none',
      scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: 1 },
    })
    gsap.to('.hero-giant-word', {
      xPercent: -24, ease: 'none',
      scrollTrigger: { trigger: '.hero', start: 'top top', end: 'bottom top', scrub: 1.2 },
    })

    gsap.utils.toArray<HTMLElement>('[data-reveal]').forEach((el) => {
      gsap.fromTo(el, { y: 70, autoAlpha: 0, rotateX: 5 }, {
        y: 0, autoAlpha: 1, rotateX: 0, duration: 1, ease: 'power3.out',
        scrollTrigger: { trigger: el, start: 'top 88%', toggleActions: 'play none none reverse' },
      })
    })

    gsap.utils.toArray<HTMLElement>('.skill-chip').forEach((el, i) => {
      gsap.fromTo(el, { y: 35, autoAlpha: 0, rotate: i % 2 ? 5 : -5 }, {
        y: 0, autoAlpha: 1, rotate: 0, duration: .65, delay: (i % 4) * .07,
        scrollTrigger: { trigger: '.skills-cloud', start: 'top 82%' },
      })
    })

    gsap.to('.about-portrait', {
      y: -70, rotate: 3, ease: 'none',
      scrollTrigger: { trigger: '.about-grid', start: 'top bottom', end: 'bottom top', scrub: 1 },
    })

    gsap.to('.journey-line-fill', {
      scaleY: 1, transformOrigin: 'top center', ease: 'none',
      scrollTrigger: { trigger: '.journey-list', start: 'top 70%', end: 'bottom 70%', scrub: .5 },
    })

    gsap.to('.marquee-track', {
      xPercent: -35, ease: 'none',
      scrollTrigger: { trigger: '.marquee-section', start: 'top bottom', end: 'bottom top', scrub: 1 },
    })
  }, { scope: root })

  const toggleTheme = () => setTheme(current => current === 'dark' ? 'light' : 'dark')
  const closeMenu = () => setMenuOpen(false)

  return (
    <div ref={root} className="site-shell">
      <div className="scroll-progress" style={{ transform: `scaleX(${scroll})` }} />
      <header className="site-header">
        <a className="brand" href="#top" aria-label="HARI404 home">HARI<span>404</span><i>®</i></a>
        <nav className="desktop-nav">
          {navItems.map(([label, href]) => <a key={label} href={href}>{label}</a>)}
        </nav>
        <div className="header-actions">
          <button className="theme-toggle" onClick={toggleTheme} aria-label="Toggle colour theme">
            {theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}
            <span>{theme === 'dark' ? 'LIGHT' : 'DARK'}</span>
          </button>
          <a className="header-cta" href="#contact">LET'S TALK <ArrowUpRight size={14} /></a>
          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen ? <X /> : <Menu />}</button>
        </div>
      </header>

      {menuOpen && <div className="mobile-menu">{navItems.map(([label, href]) => <a key={label} href={href} onClick={closeMenu}>{label}<ArrowUpRight /></a>)}<button onClick={toggleTheme}>Switch theme</button></div>}

      <main id="top">
        <section className="hero section-pad">
          <div className="hero-noise" />
          <div className="hero-kicker"><span className="status-dot" /> AVAILABLE FOR IDEAS & COLLABORATIONS <span className="hero-kicker-right">PORTFOLIO / 2026</span></div>
          <div className="hero-main">
            <div className="hero-heading">
              <p className="eyebrow">HELLO, WORLD. I'M</p>
              <h1 ref={heroTitle}>
                <span className="hero-line"><span>HARI</span></span>
                <span className="hero-line hero-line-accent"><span>KRISHNA<span className="hero-period">.</span></span></span>
              </h1>
              <div className="hero-copy">
                <p>Developer in progress. <em>Curiosity</em> in motion.<br />Building ideas into digital experiences.</p>
                <a href="#work" className="text-link">EXPLORE MY WORK <ArrowDownRight size={17} /></a>
              </div>
            </div>
            <div className="hero-portrait-wrap">
              <div className="portrait-ring ring-a" />
              <div className="portrait-ring ring-b" />
              <div className="portrait-sticker">CREATIVE<br />BY DEFAULT <Sparkles size={18} /></div>
              <img className="hero-portrait" src={avatarImage} alt="Illustrated cartoon portrait of Harikrishna" />
              <div className="portrait-caption">FIG. 001 — THE HUMAN BEHIND THE CODE</div>
            </div>
          </div>
          <div className="hero-giant-word" aria-hidden="true">DIGITAL CRAFT · DIGITAL CRAFT ·</div>
          <div className="hero-bottom">
            <span>SCROLL TO EXPLORE <ArrowDown size={14} /></span>
            <span>BASED IN KANNUR, INDIA</span>
            <span>01 — 09</span>
          </div>
        </section>

        <section className="intro-strip">
          <div className="intro-strip-label">A QUICK INTRODUCTION</div>
          <p>Not just writing code. <span>Exploring what code can create.</span></p>
          <div className="intro-strip-mark">✳</div>
        </section>

        <section className="about section-pad" id="about">
          <div className="section-top"><span className="eyebrow">01 / THE PERSON</span><span className="eyebrow">A LITTLE CONTEXT</span></div>
          <div className="about-grid">
            <div className="about-left" data-reveal>
              <p className="section-label">WHO'S HARI?</p>
              <h2>Curious mind.<br /><span>Builder's</span> mindset.</h2>
              <p className="body-large">I'm Harikrishna K — a computer science engineering student, aspiring software developer and technology enthusiast.</p>
              <p className="body-copy">I enjoy exploring how technology works, solving problems and turning ideas into practical digital experiences. From websites to databases and networking, I'm interested in understanding the systems behind the screen.</p>
              <a className="underlined-link" href="https://github.com/devstack-hk08" target="_blank" rel="noreferrer">MORE ABOUT MY WORK <ArrowUpRight size={16} /></a>
            </div>
            <div className="about-right">
              <div className="about-portrait-frame">
                <span className="frame-index">HK / 001</span>
                <img className="about-portrait" src={avatarImage} alt="Harikrishna illustrated avatar" />
                <span className="frame-note">ALWAYS IN<br />BUILD MODE.</span>
              </div>
              <div className="about-facts">
                <div><span>EDUCATION</span><strong>B.Tech · CSE</strong></div>
                <div><span>INSTITUTION</span><strong>Vimal Jyothi Engineering College</strong></div>
                <div><span>LOCATION</span><strong>Kannur, Kerala, India</strong></div>
              </div>
            </div>
          </div>
        </section>

        <section className="expertise section-pad" id="expertise">
          <div className="section-top"><span className="eyebrow">02 / THE TOOLKIT</span><span className="eyebrow">ALWAYS EXPANDING</span></div>
          <div className="expertise-heading" data-reveal>
            <p className="section-label">THINGS I EXPLORE</p>
            <h2>Learning by<br /><span>making.</span></h2>
            <p className="heading-aside">A growing toolkit — built through curiosity, practice and projects.</p>
          </div>
          <div className="discipline-grid">
            <div className="discipline-card" data-reveal><div className="discipline-icon"><Code2 /></div><span>01 / SOFTWARE</span><h3>Software<br />Development</h3><p>Logic, programming and turning problems into working solutions.</p><ArrowUpRight /></div>
            <div className="discipline-card" data-reveal><div className="discipline-icon"><Sparkles /></div><span>02 / WEB</span><h3>Web<br />Experiences</h3><p>Building useful, expressive and responsive digital spaces.</p><ArrowUpRight /></div>
            <div className="discipline-card" data-reveal><div className="discipline-icon"><Network /></div><span>03 / NETWORKS</span><h3>Networking</h3><p>Understanding how devices, systems and the internet connect.</p><ArrowUpRight /></div>
            <div className="discipline-card" data-reveal><div className="discipline-icon"><ShieldCheck /></div><span>04 / SECURITY</span><h3>Cybersecurity</h3><p>Exploring security fundamentals and safer digital systems.</p><ArrowUpRight /></div>
            <div className="discipline-card" data-reveal><div className="discipline-icon"><Database /></div><span>05 / DATA</span><h3>Databases</h3><p>Structuring, storing and working with information.</p><ArrowUpRight /></div>
          </div>
          <div className="skills-area">
            <div className="skills-head"><span className="eyebrow">CURRENT TOOLKIT</span><span className="eyebrow">12 TECHNOLOGIES / AREAS</span></div>
            <div className="skills-cloud">{skills.map((skill, i) => <div className="skill-chip" key={skill.name}><span className="skill-index">{String(i + 1).padStart(2, '0')}</span><strong>{skill.name}</strong><span className="skill-group">{skill.group}</span></div>)}</div>
          </div>
        </section>

        <section className="marquee-section">
          <div className="marquee-label">A MINDSET, NOT A FINISH LINE</div>
          <div className="marquee-track"><span>LEARN · BUILD · BREAK · IMPROVE · </span><span>LEARN · BUILD · BREAK · IMPROVE · </span></div>
        </section>

        <section className="work section-pad" id="work">
          <div className="section-top"><span className="eyebrow">03 / SELECTED WORK</span><span className="eyebrow">IDEAS MADE TANGIBLE</span></div>
          <div className="work-heading" data-reveal>
            <div><p className="section-label">A FEW THINGS I'VE BUILT</p><h2>Less talk.<br /><span>More making.</span></h2></div>
            <p className="heading-aside">A collection of experiments, client websites and learning projects. Each one is another step forward.</p>
          </div>
          <div className="projects-grid">{projects.map((project, i) => <div data-reveal key={project.number}><ProjectCard project={project} index={i} /></div>)}</div>
        </section>

        <section className="journey section-pad" id="journey">
          <div className="section-top"><span className="eyebrow">04 / THE JOURNEY</span><span className="eyebrow">STILL IN THE MAKING</span></div>
          <div className="journey-heading" data-reveal><p className="section-label">NOT A STRAIGHT LINE</p><h2>Progress over<br /><span>perfection.</span></h2></div>
          <div className="journey-list">
            <div className="journey-line"><div className="journey-line-fill" /></div>
            <article className="journey-item" data-reveal><span className="journey-dot">01</span><div className="journey-date">FOUNDATIONS</div><div><h3>Curiosity starts early.</h3><p>School years at Kendriya Vidyalaya and participation in the Atal Tinkering Lab helped nurture an interest in technology, experimentation and building.</p></div><span className="journey-side">EXPLORATION</span></article>
            <article className="journey-item" data-reveal><span className="journey-dot">02</span><div className="journey-date">2026 — NOW</div><div><h3>Computer science, in depth.</h3><p>Beginning the B.Tech journey in Computer Science and Engineering at Vimal Jyothi Engineering College, Kannur.</p></div><span className="journey-side">B.TECH / CSE</span></article>
            <article className="journey-item" data-reveal><span className="journey-dot">03</span><div className="journey-date">WHAT'S NEXT</div><div><h3>Keep building. Keep learning.</h3><p>Deepening skills in software development, web technologies, databases, networking and cybersecurity through consistent practice.</p></div><span className="journey-side">IN PROGRESS</span></article>
          </div>
        </section>

        <section className="principles section-pad">
          <div className="section-top"><span className="eyebrow">05 / HOW I APPROACH THINGS</span><span className="eyebrow">PERSONAL PRINCIPLES</span></div>
          <h2 className="principles-title" data-reveal>Good work starts<br />with <span>good questions.</span></h2>
          <div className="principles-list">{principles.map(([n, title, copy]) => <div className="principle-row" data-reveal key={n}><span>{n}</span><h3>{title}</h3><p>{copy}</p><ArrowUpRight /></div>)}</div>
        </section>

        <section className="contact section-pad" id="contact">
          <div className="contact-orb orb-one" /><div className="contact-orb orb-two" />
          <div className="section-top"><span className="eyebrow">06 / THE NEXT CHAPTER</span><span className="eyebrow">YOUR MOVE</span></div>
          <div className="contact-main" data-reveal>
            <p className="section-label">HAVE AN IDEA?</p>
            <h2>LET'S MAKE<br /><span>IT HAPPEN.</span></h2>
            <a className="contact-button" href="mailto:hello@hari404.dev">START A CONVERSATION <ArrowUpRight /></a>
          </div>
          <div className="contact-bottom">
            <div><span className="eyebrow">FIND ME ELSEWHERE</span><div className="social-links"><a href="https://github.com/devstack-hk08" target="_blank" rel="noreferrer"><Github /> GITHUB <ArrowUpRight /></a><a href="https://linkedin.com/in/harikrishna-k-cse008" target="_blank" rel="noreferrer"><Linkedin /> LINKEDIN <ArrowUpRight /></a></div></div>
            <div className="contact-email"><span className="eyebrow">EMAIL</span><a href="mailto:hello@hari404.dev">hello@hari404.dev</a><span className="email-note">Replace this address if your mailbox differs.</span></div>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <a className="brand footer-brand" href="#top">HARI<span>404</span><i>®</i></a>
        <span>DESIGNED TO KEEP MOVING.</span>
        <a href="#top">BACK TO TOP <ArrowUpRight size={14} /></a>
        <span>© {new Date().getFullYear()} HARIKRISHNA K</span>
      </footer>
      <div className="cursor-aura" aria-hidden="true"><MousePointer2 size={13} /></div>
    </div>
  )
}

export default App
